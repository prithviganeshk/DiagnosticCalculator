package com.example.diagnosticcalculator;

import java.util.ArrayList;
import java.util.HashMap;

public class Database {
	private HashMap<String, ArrayList<Test>> diagData = new HashMap<String, ArrayList<Test>>();
	private HashMap<String, String> hintData = new HashMap<String, String>();

	public Database() {
		//Disease1: Occult Bacteremia
		String d1 = "Occult Bacteremia";
		String hint1  = "Unimmunizaed children ages 3 months to 36 months with fever >39C and " +
				"	WBC>15 have a >10% chance of having occult bacteremia";
		hintData.put(d1, hint1);
		ArrayList<Test> testDis1 = new ArrayList<Test>();
		Test t1 = new Test("CRP > 4.4 mg/dL", 0.63, 0.81,1);
		Test t2 = new Test("Procalcitonin > 0.3 ng/mL", 0.93, 0.63, 2);
		
		testDis1.add(t1);
		testDis1.add(t2);
		diagData.put(d1, testDis1);

		//disease 2: Appendicitis
		String d2 = "Appendicitis";
		String hint2 = "Children with fever > 38, nausea or vomiting, and " +
				"	anorexia have a pretest probability of between 8 to 48% of having appendicitis. ";
		hintData.put(d2, hint2);
		ArrayList<Test> testDis2 = new ArrayList<Test>();
		Test t3 = new Test("CBC with Differential WBC>11.0", 0.78, 0.71,1);
		Test t4 = new Test("CRP > 5 mg/dL", 0.86, 0.56,1);
		Test t5 = new Test("Abdominal UltraSound", 0.84, 0.94,2);
		Test t6 = new Test("Abdominal CT", 1.0, 0.91,3);
		
		testDis2.add(t3);
		testDis2.add(t4);
		testDis2.add(t5);
		testDis2.add(t6);
		diagData.put(d2, testDis2);
		
		//disease 3 : Urinary Tract Infection
		String d3 = "Urinary Tract Infection";
		String hint3 ="For white girls ages 0 to 24 months with temp >39C, the pretest probability of UTI is 16%. For boys ages 0 to 24 months with fever, it was 8%.  For children <19 years old " +
				"with urinary symptoms and/or fever, the pretest probability was 7.8%.  ";
		hintData.put(d3, hint3);	
		ArrayList<Test> testDis3 = new ArrayList<Test>();
		Test t7 = new Test("Urinalysis",0.83,0.85,1);
		
		testDis3.add(t7);
		diagData.put(d3,testDis3);
		
	}

	public HashMap<String, ArrayList<Test>> getDiagData() {
		return diagData;
	}

	public ArrayList<Test> getTest(String Disease) {
		if (diagData.containsKey(Disease)) {
			return diagData.get(Disease);
		} else
			return null;
	}
	
	public String getPreTest(String diseaseName){
		return this.hintData.get(diseaseName);
	}
	
	public final String getRatingRange (float rate ){
		if (rate==1) return "$10-$100";
		else if (rate==2) return "$101-$500";
		else if (rate==3) return "$501-$1000";
		else return "more than $1000";
		
	}
}
