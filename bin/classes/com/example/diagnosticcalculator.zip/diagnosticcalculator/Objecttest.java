package com.example.diagnosticcalculator;

public class Objecttest{
	public String testname;
	public Double sensitivity;
	public Double specificity;
	public Double cost;
}