package com.example.diagnosticcalculator;

public class Objectdisease {
	public String disease;
	public String hint;
}